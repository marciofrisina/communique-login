# Communique Login — Baseline 1.2

Status: primeiro experimento da versão 1.2, iniciado em 3 de agosto de 2026.

Arquivo de entrada: `index.html`

Esta versão parte da 1.1 e acrescenta uma autenticação simulada. Quando as credenciais de teste são aceitas, o cartão de login se divide em quatro faixas e se dobra para dentro antes de a página ser recarregada.

Credenciais do protótipo:

- Email: `communique`
- Password: `cinemark`

Pontos de restauração preservados:

- Versões anteriores: `../versao-1.0/` e `../versao-1.1/`
- Código experimental original que originou esta entrega: `../ultima-opcao-plasma/`
