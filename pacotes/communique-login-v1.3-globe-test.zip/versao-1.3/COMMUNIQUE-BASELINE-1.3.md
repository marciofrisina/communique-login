# Communique Login — Baseline 1.3

Status: primeiro experimento da versão 1.3, iniciado em 3 de agosto de 2026.

Arquivo de entrada: `index.html`

Esta versão parte da 1.2 e substitui o fechamento Miura-ori por uma transformação esférica. Dezoito faixas verticais do cartão envolvem um globo central; em seguida, 68 caracteres alfanuméricos distribuídos por latitude e longitude passam a integrar sua superfície. Globo, grade e caracteres compartilham uma rotação exponencial de cinco segundos, acompanhada por arcos e rastros de velocidade, antes do recarregamento.

O campo de acesso usa o rótulo `User or Email` e apresenta uma pequena bandeira circular. O país é estimado pelo IP público e combinado com o timezone IANA do navegador; se a consulta externa falhar, um mapa local de timezones fornece o fallback.

Credenciais do protótipo:

- Email: `communique`
- Password: `cinemark`

Pontos de restauração preservados:

- Versões anteriores: `../versao-1.0/`, `../versao-1.1/` e `../versao-1.2/`
- Código experimental original que originou esta entrega: `../ultima-opcao-plasma/`
