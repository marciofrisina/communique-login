# Communique 7 — Plasma Nucleus experiment

This experimental variation keeps the complete English login screen and reframes the animated background as a concentrated, blue plasma nucleus.

- Slow, irregular cloud pulse around a luminous centre.
- Multiple semi-transparent, uneven elliptical filaments moving at independent speeds.
- Small energy particles and brighter sparks held within the plasma field.
- Dense, slowly moving peripheral galaxy clouds that give the field more depth, rendered with an adaptive visual-detail budget.
- A rare, slow meteor or comet pass with a soft, fading tail.
- A warm amber pulsing light source travelling a smaller, invisible ellipse around the login card. Its longer local tail fades continuously, with the upper orbit behind the card and the lower orbit over it.
- Pointer movement produces only a subtle parallax shift.
- The effect honours `prefers-reduced-motion`.

The previous Plasma experiment and the protected Communique baseline 1.0 are intentionally left unchanged.
